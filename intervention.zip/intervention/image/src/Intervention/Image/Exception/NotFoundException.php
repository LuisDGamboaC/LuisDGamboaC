<?php

namespace Intervention\Image\Exception;

class NotFoundException extends ImageException
{
    # nothing to override
}
